package edu.davenport.cisp340.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";

    private static final String DB_NAME = "Animal Tracker";
    private static final int DB_VERSION = 2;

    DBHelper db;

    public DBHelper(Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String sqlAnimal = "CREATE TABLE animal(id INTEGER PRIMARY KEY AUTOINCREMENT, name VARCHAR);";
        String sqlInfo = "CREATE TABLE info(id INTEGER PRIMARY KEY AUTOINCREMENT, animal_id INTEGER, count INTEGER," +
                "seen TEXT, comments VARCHAR, Loc_latitude REAL, Loc_longitude REAL, FOREIGN KEY(animal_id) REFERENCES animal(id))";

        db.execSQL(sqlAnimal);
        db.execSQL(sqlInfo);


    }

    public  boolean addAnimal(String name){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        db.insert("animal", null, contentValues);
        db.close();
        return true;
    }
    public boolean addLocation(double lat, double log){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Loc_latitude", lat);
        contentValues.put("Loc_logitude", log);
        db.insert("info", null, contentValues);
        db.close();
        return true;
    }
    public boolean addData(String item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("animal_id", item);

        Log.d(TAG, "addData: Adding " + item + " to " + "info");

        long result = db.insert("info", null, contentValues);

        //if date as inserted incorrectly it will return -1
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Cursor getData(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + "info";
        Cursor data = db.rawQuery(query, null);
        return data;
    }


    public Cursor getItemID(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT " + "id" + " FROM " + "info" +
                " WHERE " + "animal_id" + " = '" + name + "'";
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sqlAnimal = "DROP TABLE IF EXISTS animal";
        String sqlInfo = "DROP TABLE IF EXISTS info";

        db.execSQL(sqlInfo);
        db.execSQL(sqlAnimal);

        onCreate(db);
    }

    public void updateName(String newName, int id, String oldName){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "UPDATE " + "info" + " SET " + "animal_id" +
                " = '" + newName + "' WHERE " + "id" + " = '" + id + "'" +
                " AND " + "animal_id" + " = '" + oldName + "'";
        Log.d(TAG, "updateName: query: " + query);
        Log.d(TAG, "updateName: Setting name to " + newName);
        db.execSQL(query);
    }

    /**
     * Delete from database
     * @param id
     * @param name
     */
    public void deleteName(int id, String name){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "DELETE FROM " + "info" + " WHERE "
                + "id" + " = '" + id + "'" +
                " AND " + "animal_id" + " = '" + name + "'";
        Log.d(TAG, "deleteName: query: " + query);
        Log.d(TAG, "deleteName: Deleting " + name + " from database.");
        db.execSQL(query);
    }

}
